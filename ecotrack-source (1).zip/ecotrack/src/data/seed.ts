/**
 * Deterministic seed data for the demo: 1 company, 5 teams, 3 offices,
 * 40 employees and 8 weeks of activity. Everything is generated from a
 * seeded PRNG so charts look identical on every load.
 */
import { calculateEmissions, type Mode } from "@/utils/emissions";

function rng(seed: number) {
  let s = seed;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}
const rand = rng(42);

export const COMPANY = { name: "Acme Tech Park, Chennai", domain: "acmetech.in" };
export const TEAMS = ["Engineering", "HR", "Sales", "Ops", "Finance"] as const;
export type Team = (typeof TEAMS)[number];

export interface Office { id: string; name: string; city: string }
export const OFFICES: Office[] = [
  { id: "chn-omr", name: "Chennai – OMR (HQ)", city: "Chennai" },
  { id: "chn-gdy", name: "Chennai – Guindy", city: "Chennai" },
  { id: "blr-wf", name: "Bengaluru – Whitefield", city: "Bengaluru" },
];

const FIRST = ["Priya","Arjun","Kavya","Rahul","Divya","Karthik","Ananya","Vikram","Meera","Suresh","Lakshmi","Rohan","Sneha","Aditya","Pooja","Harish","Nandini","Siddharth","Ishita","Manoj","Deepa","Gautam","Revathi","Naveen","Aisha","Prakash","Swathi","Varun","Janani","Ajay","Shruti","Ramesh","Keerthi","Nikhil","Bhavana","Imran","Gayathri","Farhan","Tanvi","Senthil"];
const LAST = ["Raman","Iyer","Nair","Sharma","Reddy","Krishnan","Menon","Patel","Subramanian","Rao","Pillai","Gupta","Joshi","Mehta","Kumar","Das","Bose","Verma","Shetty","Khan"];

/** Week labels: 8 weeks ending this week. */
export const WEEKS: string[] = Array.from({ length: 8 }, (_, i) => {
  const d = new Date();
  d.setDate(d.getDate() - (7 - i) * 7);
  return d.toLocaleDateString("en-IN", { day: "numeric", month: "short" });
});

export interface Employee {
  id: string;
  name: string;
  team: Team;
  officeId: string;
  participating: boolean;
  baselineWeekly: number; // kg CO2 commute baseline / week
  commute: number[]; // GHG Cat 7, kg per week (8 weeks)
  travel: number[]; // GHG Cat 6, kg per week (8 weeks)
}

export const EMPLOYEES: Employee[] = FIRST.map((first, i) => {
  const team = TEAMS[i % 5]!;
  const officeId = OFFICES[i % 7 < 4 ? 0 : i % 7 < 6 ? 1 : 2]!.id;
  const baselineWeekly = Math.round((6 + rand() * 30) * 10) / 10;
  const rate = 0.05 + rand() * 0.35; // how much they improve over 8 weeks
  const commute = Array.from({ length: 8 }, (_, w) =>
    Math.round(baselineWeekly * (1 - (rate * w) / 7) * (0.9 + rand() * 0.2) * 10) / 10,
  );
  const travelChance = team === "Sales" ? 0.45 : team === "Ops" ? 0.2 : 0.08;
  const travel = Array.from({ length: 8 }, () =>
    rand() < travelChance ? Math.round(calculateEmissions("flight", 300 + rand() * 1500) * 2) : 0,
  );
  return {
    id: `e${i}`,
    name: `${first} ${LAST[i % LAST.length]}`,
    team,
    officeId,
    participating: i === 0 || rand() > 0.18,
    baselineWeekly,
    commute,
    travel,
  };
});

/* ---------- Current demo user's personal logs ---------- */
export interface TripLog {
  id: string;
  date: string; // ISO date (yyyy-mm-dd)
  mode: Mode;
  km: number;
  kg: number;
  source: "manual" | "auto";
}

const iso = (d: Date) => d.toISOString().slice(0, 10);

export function seedUserLogs(): TripLog[] {
  const r = rng(7);
  const logs: TripLog[] = [];
  const commuteKm = 14;
  for (let back = 55; back >= 0; back--) {
    const d = new Date();
    d.setDate(d.getDate() - back);
    const dow = d.getDay();
    if (dow === 0 || dow === 6) continue;
    if (r() < 0.15 && back > 3) continue; // WFH day
    const progress = 1 - back / 55; // later weeks = greener choices
    const roll = r();
    const mode: Mode =
      roll < 0.55 - progress * 0.4 ? "car" : roll < 0.75 - progress * 0.2 ? "cab" : roll < 0.9 ? "metro" : r() < 0.5 ? "bus" : "two-wheeler";
    for (let leg = 0; leg < 2; leg++) {
      logs.push({ id: `l${back}-${leg}`, date: iso(d), mode, km: commuteKm, kg: calculateEmissions(mode, commuteKm), source: "manual" });
    }
  }
  // One business trip Chennai → Bengaluru, 5 weeks ago
  const t = new Date();
  t.setDate(t.getDate() - 36);
  logs.push({ id: "flight-1", date: iso(t), mode: "flight", km: 290, kg: calculateEmissions("flight", 290), source: "manual" });
  return logs;
}

export interface DetectedTrip { id: string; time: string; from: string; to: string; mode: Mode; km: number }
export const SEED_DETECTED: DetectedTrip[] = [
  { id: "d1", time: "Today, 8:42 AM", from: "Velachery", to: "Acme Tech Park, OMR", mode: "metro", km: 13.6 },
  { id: "d2", time: "Today, 1:10 PM", from: "Acme Tech Park", to: "Thoraipakkam", mode: "walk", km: 1.2 },
  { id: "d3", time: "Yesterday, 7:05 PM", from: "Acme Tech Park, OMR", to: "Velachery", mode: "cab", km: 14.1 },
];

export interface Challenge {
  id: string; name: string; target: string; durationDays: number; reward: string;
  status: "active" | "past"; participants: number; progress: number;
}
export const SEED_CHALLENGES: Challenge[] = [
  { id: "c1", name: "Metro Mondays", target: "Commute by metro every Monday", durationDays: 28, reward: "₹500 Swiggy voucher", status: "active", participants: 24, progress: 62 },
  { id: "c2", name: "Car-free Week", target: "No solo car trips for 5 workdays", durationDays: 7, reward: "Extra half-day leave", status: "active", participants: 15, progress: 40 },
  { id: "c3", name: "Print Less October", target: "Under 20 pages printed per person", durationDays: 31, reward: "Tree planted in your name", status: "past", participants: 33, progress: 100 },
];

export interface Reward { id: string; title: string; points: number; kind: "voucher" | "leave" | "tree" }
export const REWARDS: Reward[] = [
  { id: "r1", title: "Tree planted in your name", points: 300, kind: "tree" },
  { id: "r2", title: "₹500 Amazon voucher", points: 800, kind: "voucher" },
  { id: "r3", title: "₹1,000 Decathlon voucher", points: 1500, kind: "voucher" },
  { id: "r4", title: "Extra day of leave", points: 2500, kind: "leave" },
];
