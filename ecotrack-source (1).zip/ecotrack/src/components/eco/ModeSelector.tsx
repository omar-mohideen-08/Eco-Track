import { Bike, Bus, Car, CarTaxiFront, Footprints, Plane, TrainFront, TramFront, Bike as Scooter, Truck, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { EMISSION_FACTORS, MODE_LABELS, MODES, type Mode } from "@/utils/emissions";

export const MODE_ICONS: Record<Mode, LucideIcon> = {
  walk: Footprints, cycle: Bike, "two-wheeler": Scooter, "auto-rickshaw": Truck, car: Car,
  cab: CarTaxiFront, bus: Bus, metro: TramFront, train: TrainFront, flight: Plane,
};

const ORDER: Mode[] = ["walk", "cycle", "two-wheeler", "auto-rickshaw", "car", "cab", "bus", "metro", "train", "flight"];

/** Big tap-friendly mode buttons (radio group semantics). */
export function ModeSelector({ value, onChange, compact }: { value: Mode | null; onChange: (m: Mode) => void; compact?: boolean }) {
  return (
    <div role="radiogroup" aria-label="Travel mode" className={cn("grid gap-2", compact ? "grid-cols-5" : "grid-cols-3 sm:grid-cols-5")}>
      {ORDER.filter((m) => MODES.includes(m)).map((m) => {
        const Icon = MODE_ICONS[m];
        const active = value === m;
        return (
          <button key={m} type="button" role="radio" aria-checked={active} onClick={() => onChange(m)}
            className={cn(
              "flex flex-col items-center gap-1 rounded-2xl border-2 p-3 text-xs font-semibold transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring active:scale-95",
              active ? "border-primary bg-primary text-primary-foreground shadow-float" : "border-border bg-card hover:border-primary/50",
            )}>
            <Icon className="size-6" aria-hidden />
            <span className="leading-tight">{MODE_LABELS[m]}</span>
            {!compact && <span className={cn("text-[10px] font-normal", active ? "opacity-90" : "text-muted-foreground")}>{EMISSION_FACTORS[m]} kg/km</span>}
          </button>
        );
      })}
    </div>
  );
}
