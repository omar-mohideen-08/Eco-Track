/** Small shared building blocks: CountUp, ProgressRing, Co2Badge, states, logo. */
import { useEffect, useRef, useState, type ReactNode } from "react";
import { AlertTriangle, Leaf, Moon, Sun, TrendingDown, TrendingUp, Minus, Inbox } from "lucide-react";
import confetti from "canvas-confetti";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { useApp } from "@/store/app-store";
import type { Co2Level } from "@/utils/emissions";

export function Logo({ className }: { className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-2 font-display text-lg font-bold", className)}>
      <span className="grid size-8 place-items-center rounded-xl bg-hero text-primary-foreground shadow-card">
        <Leaf className="size-4" aria-hidden />
      </span>
      EcoTrack
    </span>
  );
}

/** Animated number that counts up from 0 on mount / change. */
export function CountUp({ value, decimals = 0, duration = 900 }: { value: number; decimals?: number; duration?: number }) {
  const [n, setN] = useState(0);
  const from = useRef(0);
  useEffect(() => {
    const start = performance.now();
    const a = from.current;
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setN(a + (value - a) * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
      else from.current = value;
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value, duration]);
  return <>{n.toLocaleString("en-IN", { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}</>;
}

/** Animated circular progress ring. */
export function ProgressRing({ value, size = 140, stroke = 12, label, sub }: { value: number; size?: number; stroke?: number; label: string; sub?: string }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const [shown, setShown] = useState(0);
  useEffect(() => { const t = setTimeout(() => setShown(Math.max(0, Math.min(100, value))), 50); return () => clearTimeout(t); }, [value]);
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }} role="img" aria-label={`${label}: ${value.toFixed(0)} percent`}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--muted)" strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--primary)" strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c - (shown / 100) * c} style={{ transition: "stroke-dashoffset 1.1s cubic-bezier(.2,.7,.2,1)" }} />
      </svg>
      <div className="absolute text-center">
        <div className="font-display text-3xl font-bold">{value >= 0 ? "" : "−"}<CountUp value={Math.abs(value)} />%</div>
        {sub && <div className="text-xs text-muted-foreground">{sub}</div>}
      </div>
    </div>
  );
}

const LEVEL: Record<Co2Level, { text: string; cls: string }> = {
  low: { text: "Low", cls: "bg-co2-low/15 text-co2-low" },
  medium: { text: "Medium", cls: "bg-co2-medium/15 text-co2-medium" },
  high: { text: "High", cls: "bg-co2-high/15 text-co2-high" },
};
/** CO2 level pill — always shows text + icon, never color alone. */
export function Co2Badge({ level }: { level: Co2Level }) {
  const Icon = level === "low" ? TrendingDown : level === "high" ? TrendingUp : Minus;
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold", LEVEL[level].cls)}>
      <Icon className="size-3" aria-hidden /> {LEVEL[level].text}
    </span>
  );
}

export function Card({ className, children, ...rest }: { className?: string; children: ReactNode } & React.HTMLAttributes<HTMLElement>) {
  return <section className={cn("rounded-2xl border bg-card p-5 text-card-foreground shadow-card animate-rise", className)} {...rest}>{children}</section>;
}

export function CardSkeleton({ h = 140 }: { h?: number }) {
  return <Skeleton className="w-full rounded-2xl" style={{ height: h }} aria-label="Loading" />;
}

export function EmptyState({ title, body, action }: { title: string; body?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-2xl border border-dashed p-8 text-center">
      <Inbox className="size-8 text-muted-foreground" aria-hidden />
      <p className="font-semibold">{title}</p>
      {body && <p className="max-w-sm text-sm text-muted-foreground">{body}</p>}
      {action}
    </div>
  );
}

export function ErrorState({ onRetry }: { onRetry: () => void }) {
  return (
    <div role="alert" className="flex flex-col items-center gap-2 rounded-2xl border border-destructive/40 p-8 text-center">
      <AlertTriangle className="size-8 text-destructive" aria-hidden />
      <p className="font-semibold">We couldn't load this right now</p>
      <p className="text-sm text-muted-foreground">Check your connection and try again — your data is safe.</p>
      <Button variant="outline" onClick={onRetry}>Try again</Button>
    </div>
  );
}

export function ThemeToggle() {
  const theme = useApp((s) => s.theme);
  const toggle = useApp((s) => s.toggleTheme);
  return (
    <Button variant="ghost" size="icon" onClick={toggle} aria-label={`Switch to ${theme === "light" ? "dark" : "light"} mode`}>
      {theme === "light" ? <Moon className="size-5" /> : <Sun className="size-5" />}
    </Button>
  );
}

export function celebrate() {
  if (typeof window === "undefined" || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  confetti({ particleCount: 90, spread: 70, origin: { y: 0.7 }, colors: ["#1f6b45", "#b6e34a", "#f4c542"] });
}

export function PageTitle({ title, sub, action }: { title: string; sub?: string; action?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-bold md:text-3xl">{title}</h1>
        {sub && <p className="mt-1 text-sm text-muted-foreground">{sub}</p>}
      </div>
      {action}
    </div>
  );
}
