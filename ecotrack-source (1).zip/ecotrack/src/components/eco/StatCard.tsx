import type { LucideIcon } from "lucide-react";
import { TrendingDown, TrendingUp } from "lucide-react";
import { cn } from "@/lib/utils";
import { Card, Co2Badge, CountUp } from "./primitives";
import type { Co2Level } from "@/utils/emissions";

interface Props {
  label: string;
  value: number;
  unit?: string;
  decimals?: number;
  icon?: LucideIcon;
  /** % change; negative is good (lower emissions). */
  change?: number | undefined;
  changeLabel?: string;
  level?: Co2Level;
  className?: string;
}

export function StatCard({ label, value, unit, decimals = 1, icon: Icon, change, changeLabel, level, className }: Props) {
  const good = change !== undefined && change <= 0;
  return (
    <Card className={cn("p-4", className)}>
      <div className="flex items-start justify-between gap-2">
        <p className="text-sm font-medium text-muted-foreground">{label}</p>
        {Icon && <span className="grid size-8 place-items-center rounded-lg bg-secondary text-secondary-foreground"><Icon className="size-4" aria-hidden /></span>}
      </div>
      <p className="mt-2 font-display text-2xl font-bold md:text-3xl">
        <CountUp value={value} decimals={decimals} />
        {unit && <span className="ml-1 text-sm font-medium text-muted-foreground">{unit}</span>}
      </p>
      <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
        {level && <Co2Badge level={level} />}
        {change !== undefined && (
          <span className={cn("inline-flex items-center gap-1 font-semibold", good ? "text-co2-low" : "text-co2-high")}>
            {good ? <TrendingDown className="size-3" aria-hidden /> : <TrendingUp className="size-3" aria-hidden />}
            {change > 0 ? "+" : ""}{change}% <span className="font-normal text-muted-foreground">{changeLabel}</span>
          </span>
        )}
      </div>
    </Card>
  );
}
