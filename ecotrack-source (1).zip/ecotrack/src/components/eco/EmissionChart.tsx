/**
 * Chart wrappers around Recharts. Each chart is wrapped in a <figure> with an
 * aria-label and a visually hidden data table so screen readers get the data.
 */
import { Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { MODE_COLORS, MODE_LABELS, type Mode } from "@/utils/emissions";

const tooltipStyle = { background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 12, color: "var(--popover-foreground)", fontSize: 12 };
const axis = { stroke: "var(--muted-foreground)", fontSize: 12, tickLine: false, axisLine: false };

function SrTable({ rows, cols }: { rows: Record<string, unknown>[]; cols: string[] }) {
  return (
    <table className="sr-only">
      <thead><tr>{cols.map((c) => <th key={c}>{c}</th>)}</tr></thead>
      <tbody>{rows.map((r, i) => <tr key={i}>{cols.map((c) => <td key={c}>{String(r[c] ?? 0)}</td>)}</tr>)}</tbody>
    </table>
  );
}

export function WeeklyModeBar({ data, modes }: { data: Record<string, number | string>[]; modes: Mode[] }) {
  return (
    <figure aria-label="Kilograms of CO2 per day for the last 7 days, stacked by travel mode">
      <div className="h-56">
        <ResponsiveContainer>
          <BarChart data={data}>
            <CartesianGrid vertical={false} stroke="var(--border)" />
            <XAxis dataKey="day" {...axis} />
            <YAxis {...axis} width={30} />
            <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "var(--muted)" }} formatter={(v: number, n: string) => [`${v} kg`, MODE_LABELS[n as Mode]]} />
            {modes.map((m, i) => <Bar key={m} dataKey={m} stackId="a" fill={MODE_COLORS[m]} radius={i === modes.length - 1 ? [6, 6, 0, 0] : 0} />)}
          </BarChart>
        </ResponsiveContainer>
      </div>
      <SrTable rows={data} cols={["day", ...modes]} />
    </figure>
  );
}

export function ModeDonut({ data, label = "Mode breakdown" }: { data: { mode: string; kg: number }[]; label?: string }) {
  const total = data.reduce((s, d) => s + d.kg, 0);
  return (
    <figure aria-label={`${label}, kilograms of CO2 by travel mode`} className="flex flex-col items-center gap-3 sm:flex-row">
      <div className="h-44 w-44 shrink-0">
        <ResponsiveContainer>
          <PieChart>
            <Pie data={data} dataKey="kg" nameKey="mode" innerRadius={48} outerRadius={78} paddingAngle={2} stroke="var(--card)">
              {data.map((d) => <Cell key={d.mode} fill={MODE_COLORS[d.mode as Mode] ?? "var(--chart-1)"} />)}
            </Pie>
            <Tooltip contentStyle={tooltipStyle} formatter={(v: number, n: string) => [`${v} kg`, MODE_LABELS[n as Mode] ?? n]} />
          </PieChart>
        </ResponsiveContainer>
      </div>
      <ul className="w-full space-y-1.5 text-sm">
        {data.map((d) => (
          <li key={d.mode} className="flex items-center gap-2">
            <span className="size-3 rounded-sm" style={{ background: MODE_COLORS[d.mode as Mode] }} aria-hidden />
            <span className="flex-1">{MODE_LABELS[d.mode as Mode] ?? d.mode}</span>
            <span className="font-semibold tabular-nums">{d.kg} kg</span>
            <span className="w-10 text-right text-muted-foreground tabular-nums">{total ? Math.round((d.kg / total) * 100) : 0}%</span>
          </li>
        ))}
      </ul>
    </figure>
  );
}

export function TrendLine({ data, lines, xKey = "week", label }: { data: Record<string, number | string>[]; lines: { key: string; name: string; color: string; dashed?: boolean }[]; xKey?: string; label: string }) {
  return (
    <figure aria-label={label}>
      <div className="h-64">
        <ResponsiveContainer>
          <LineChart data={data}>
            <CartesianGrid vertical={false} stroke="var(--border)" />
            <XAxis dataKey={xKey} {...axis} />
            <YAxis {...axis} width={44} />
            <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => `${v} kg`} />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            {lines.map((l) => <Line key={l.key} type="monotone" dataKey={l.key} name={l.name} stroke={l.color} strokeWidth={2.5} strokeDasharray={l.dashed ? "6 4" : undefined} dot={{ r: 3 }} />)}
          </LineChart>
        </ResponsiveContainer>
      </div>
      <SrTable rows={data} cols={[xKey, ...lines.map((l) => l.key)]} />
    </figure>
  );
}

export function GroupedBar({ data, bars, xKey, label, stacked }: { data: Record<string, number | string>[]; bars: { key: string; name: string; color: string }[]; xKey: string; label: string; stacked?: boolean }) {
  return (
    <figure aria-label={label}>
      <div className="h-64">
        <ResponsiveContainer>
          <BarChart data={data}>
            <CartesianGrid vertical={false} stroke="var(--border)" />
            <XAxis dataKey={xKey} {...axis} interval={0} tick={{ fontSize: 11 }} />
            <YAxis {...axis} width={44} />
            <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "var(--muted)" }} formatter={(v: number) => `${v} kg`} />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            {bars.map((b) => <Bar key={b.key} dataKey={b.key} name={b.name} fill={b.color} {...(stacked ? { stackId: "s" } : {})} radius={stacked ? 0 : [6, 6, 0, 0]} />)}
          </BarChart>
        </ResponsiveContainer>
      </div>
      <SrTable rows={data} cols={[xKey, ...bars.map((b) => b.key)]} />
    </figure>
  );
}
