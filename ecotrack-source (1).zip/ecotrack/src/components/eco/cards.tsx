/** LeaderboardTable, TipCard, ConsentToggle, ChallengeCard. */
import { Award, Check, Clock, Gift, Lightbulb, Medal, Target, TrendingDown, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import type { Challenge } from "@/data/seed";
import type { Tip } from "@/utils/stats";
import { Card } from "./primitives";

export interface LeaderRow { id: string; name: string; sub?: string; improvement: number; highlight?: boolean }

/** Ranks by % reduction vs. own baseline — never by absolute emissions. */
export function LeaderboardTable({ rows, caption }: { rows: LeaderRow[]; caption: string }) {
  const sorted = [...rows].sort((a, b) => b.improvement - a.improvement);
  return (
    <table className="w-full text-sm">
      <caption className="sr-only">{caption}</caption>
      <thead className="text-left text-xs text-muted-foreground">
        <tr><th scope="col" className="w-12 pb-2">Rank</th><th scope="col" className="pb-2">Name</th><th scope="col" className="pb-2 text-right">Reduction vs. baseline</th></tr>
      </thead>
      <tbody>
        {sorted.map((r, i) => (
          <tr key={r.id} aria-current={r.highlight ? "true" : undefined}
            className={cn("border-t transition-colors", r.highlight && "bg-accent/40 font-semibold")}>
            <td className="py-2.5">
              {i < 3 ? <Medal className={cn("size-5", i === 0 ? "text-co2-medium" : i === 1 ? "text-muted-foreground" : "text-co2-high")} aria-label={`Rank ${i + 1}`} /> : <span className="pl-1 tabular-nums">{i + 1}</span>}
            </td>
            <td className="py-2.5">
              <div>{r.name}{r.highlight && <span className="ml-2 rounded-full bg-primary px-2 py-0.5 text-[10px] text-primary-foreground">You</span>}</div>
              {r.sub && <div className="text-xs font-normal text-muted-foreground">{r.sub}</div>}
            </td>
            <td className="py-2.5 text-right">
              <div className="inline-flex items-center gap-2">
                <div className="hidden h-2 w-20 overflow-hidden rounded-full bg-muted sm:block" aria-hidden>
                  <div className="h-full rounded-full bg-primary" style={{ width: `${Math.max(0, Math.min(100, r.improvement * 2))}%` }} />
                </div>
                <span className={cn("tabular-nums font-semibold", r.improvement >= 0 ? "text-co2-low" : "text-co2-high")}>
                  {r.improvement >= 0 ? "↓" : "↑"} {Math.abs(r.improvement).toFixed(1)}%
                </span>
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export function TipCard({ tip, accepted, onAccept, featured }: { tip: Tip; accepted: boolean; onAccept: () => void; featured?: boolean }) {
  return (
    <Card className={cn(featured && "border-primary/40 bg-hero text-primary-foreground")}>
      <div className="flex items-start gap-3">
        <span className={cn("grid size-10 shrink-0 place-items-center rounded-xl", featured ? "bg-accent text-accent-foreground" : "bg-secondary text-secondary-foreground")}>
          <Lightbulb className="size-5" aria-hidden />
        </span>
        <div className="flex-1">
          {featured && <p className="text-xs font-semibold uppercase tracking-wider opacity-90">Your best switch</p>}
          <h3 className="text-lg font-bold">{tip.title}</h3>
          <p className={cn("mt-1 text-sm", featured ? "opacity-90" : "text-muted-foreground")}>{tip.detail}</p>
          <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
            <span className="inline-flex items-center gap-1 text-sm font-semibold"><TrendingDown className="size-4" aria-hidden /> Save ~{tip.savingKg} kg CO₂/month</span>
            <Button size="sm" variant={featured ? "secondary" : "default"} onClick={onAccept} disabled={accepted} aria-pressed={accepted}>
              {accepted ? <><Check className="size-4" /> Challenge accepted</> : "Accept challenge"}
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}

export function ConsentToggle({ id, label, description, checked, onChange }: { id: string; label: string; description: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-start justify-between gap-4 py-3">
      <div>
        <label htmlFor={id} className="font-semibold">{label}</label>
        <p id={`${id}-desc`} className="text-sm text-muted-foreground">{description}</p>
      </div>
      <Switch id={id} checked={checked} onCheckedChange={onChange} aria-describedby={`${id}-desc`} />
    </div>
  );
}

export function ChallengeCard({ challenge }: { challenge: Challenge }) {
  const past = challenge.status === "past";
  return (
    <Card className="p-4">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="grid size-9 place-items-center rounded-xl bg-secondary text-secondary-foreground">{past ? <Award className="size-4" /> : <Target className="size-4" />}</span>
          <h3 className="font-bold">{challenge.name}</h3>
        </div>
        <span className={cn("rounded-full px-2 py-0.5 text-xs font-semibold", past ? "bg-muted text-muted-foreground" : "bg-accent text-accent-foreground")}>{past ? "Completed" : "Active"}</span>
      </div>
      <p className="mt-2 text-sm text-muted-foreground">{challenge.target}</p>
      <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1"><Clock className="size-3" aria-hidden />{challenge.durationDays} days</span>
        <span className="inline-flex items-center gap-1"><Users className="size-3" aria-hidden />{challenge.participants} joined</span>
        <span className="inline-flex items-center gap-1"><Gift className="size-3" aria-hidden />{challenge.reward}</span>
      </div>
      <Progress value={challenge.progress} className="mt-3 h-2" aria-label={`${challenge.progress}% complete`} />
    </Card>
  );
}
