/** Derived personal stats from trip logs (pure functions). */
import type { TripLog } from "@/data/seed";
import { calculateSavings, capDailyPoints, MODE_LABELS, pointsForTrip, type Mode } from "./emissions";
import type { Baseline } from "@/store/app-store";

const iso = (d: Date) => d.toISOString().slice(0, 10);
const daysAgo = (n: number) => { const d = new Date(); d.setDate(d.getDate() - n); return iso(d); };
const r1 = (n: number) => Math.round(n * 10) / 10;

export function sumKg(logs: TripLog[], fromDaysAgo: number, toDaysAgo = 0) {
  const from = daysAgo(fromDaysAgo), to = daysAgo(toDaysAgo);
  return r1(logs.filter((l) => l.date >= from && l.date <= to).reduce((s, l) => s + l.kg, 0));
}

/** Last 7 days stacked by mode for the weekly bar chart. */
export function weeklyByMode(logs: TripLog[]) {
  return Array.from({ length: 7 }, (_, i) => {
    const date = daysAgo(6 - i);
    const row: Record<string, number | string> = {
      day: new Date(date).toLocaleDateString("en-IN", { weekday: "short" }),
    };
    logs.filter((l) => l.date === date).forEach((l) => { row[l.mode] = r1(((row[l.mode] as number) || 0) + l.kg); });
    return row;
  });
}

export function modeBreakdown(logs: TripLog[], days = 30) {
  const from = daysAgo(days);
  const map = new Map<Mode, number>();
  logs.filter((l) => l.date >= from).forEach((l) => map.set(l.mode, (map.get(l.mode) || 0) + l.kg));
  return [...map.entries()].map(([mode, kg]) => ({ mode, kg: r1(kg) })).filter((m) => m.kg > 0).sort((a, b) => b.kg - a.kg);
}

/** Consecutive workdays (ending today/yesterday) with at least one log. */
export function streak(logs: TripLog[]) {
  const dates = new Set(logs.map((l) => l.date));
  let count = 0;
  for (let i = 0; i < 120; i++) {
    const d = new Date(); d.setDate(d.getDate() - i);
    if (d.getDay() === 0 || d.getDay() === 6) continue;
    if (dates.has(iso(d))) count++;
    else if (i > 1) break;
  }
  return count;
}

/** Total points with the per-day cap applied. */
export function totalPoints(logs: TripLog[]) {
  const byDay = new Map<string, number>();
  logs.forEach((l) => byDay.set(l.date, (byDay.get(l.date) || 0) + pointsForTrip(l.mode, l.km)));
  return [...byDay.values()].reduce((s, p) => s + capDailyPoints(p), 0);
}

export interface Tip { id: string; title: string; detail: string; savingKg: number; from: Mode | "habits"; to?: Mode }

/** "Your best switch": tips ranked by savings from the largest source. */
export function generateTips(logs: TripLog[], baseline: Baseline): Tip[] {
  const top = modeBreakdown(logs)[0]?.mode ?? baseline.mode;
  const km = baseline.distanceKm;
  const tips: Tip[] = [];
  const add = (from: Mode, to: Mode, days: number, verb: string) => {
    const s = calculateSavings(from, to, km, days);
    if (s.perMonth > 0) tips.push({ id: `${from}-${to}-${days}`, from, to, savingKg: s.perMonth,
      title: `${verb} ${days} day${days > 1 ? "s" : ""} a week`,
      detail: `Swap ${MODE_LABELS[from].toLowerCase()} for ${MODE_LABELS[to].toLowerCase()} on your ${km} km commute to save about ${s.perMonth} kg CO₂ a month.` });
  };
  const base: Mode = top === "flight" ? baseline.mode : top;
  add(base, "metro", 2, "Take the metro");
  add(base, "bus", 3, "Ride the bus");
  add(base, "two-wheeler", 2, "Carpool or two-wheeler");
  if (km <= 6) add(base, "cycle", 3, "Cycle");
  if (top === "flight" || logs.some((l) => l.mode === "flight"))
    tips.push({ id: "flight-train", from: "flight", to: "train", savingKg: r1(290 * (0.15 - 0.04)), title: "Take the train for short trips", detail: "Choosing the Shatabdi over a Chennai–Bengaluru flight saves about 32 kg CO₂ per trip." });
  tips.push({ id: "ac-24", from: "habits", savingKg: 4.5, title: "Set the AC to 24 °C", detail: "BEE recommends 24 °C as default — it trims office energy use and about 4.5 kg CO₂ per person a month." });
  return tips.sort((a, b) => b.savingKg - a.savingKg);
}
