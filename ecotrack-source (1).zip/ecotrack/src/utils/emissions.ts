/**
 * EcoTrack emission engine (client-side).
 *
 * All factors are kg CO2 per passenger-km.
 * TODO: Replace these PLACEHOLDER India-oriented factors with official
 *       India GHG Program / CEA (Central Electricity Authority) values.
 */
export const EMISSION_FACTORS = {
  walk: 0,
  cycle: 0,
  metro: 0.03,
  train: 0.04,
  bus: 0.08,
  "two-wheeler": 0.04,
  "auto-rickshaw": 0.07,
  car: 0.17,
  cab: 0.2,
  flight: 0.15,
} as const;

export type Mode = keyof typeof EMISSION_FACTORS;
export const MODES = Object.keys(EMISSION_FACTORS) as Mode[];

export const MODE_LABELS: Record<Mode, string> = {
  walk: "Walk",
  cycle: "Cycle",
  metro: "Metro",
  train: "Train",
  bus: "Bus",
  "two-wheeler": "Two-wheeler",
  "auto-rickshaw": "Auto-rickshaw",
  car: "Car",
  cab: "Cab",
  flight: "Flight",
};

/** CSS variable used for each mode in charts (defined in styles.css). */
export const MODE_COLORS: Record<Mode, string> = {
  walk: "var(--mode-walk)",
  cycle: "var(--mode-cycle)",
  metro: "var(--mode-metro)",
  train: "var(--mode-train)",
  bus: "var(--mode-bus)",
  "two-wheeler": "var(--mode-two)",
  "auto-rickshaw": "var(--mode-auto)",
  car: "var(--mode-car)",
  cab: "var(--mode-cab)",
  flight: "var(--mode-flight)",
};

/** Modes that travel by road — used by the sanity check. */
const ROAD_MODES: Mode[] = ["walk", "cycle", "bus", "two-wheeler", "auto-rickshaw", "car", "cab"];
export const MAX_ROAD_KM_PER_DAY = 500;
export const MAX_FLIGHT_KM = 6000;
export const MAX_RAIL_KM = 3000;
export const DAILY_POINTS_CAP = 100;

const round = (n: number, d = 2) => Math.round(n * 10 ** d) / 10 ** d;

/** kg CO2 for a single trip of `distanceKm`. */
export function calculateEmissions(mode: Mode, distanceKm: number): number {
  const km = Math.max(0, Number(distanceKm) || 0);
  return round(EMISSION_FACTORS[mode] * km);
}

/**
 * Savings from switching a round-trip commute of `distanceKm` (one way)
 * from `currentMode` to `alternativeMode` on `daysPerWeek` days.
 */
export function calculateSavings(
  currentMode: Mode,
  alternativeMode: Mode,
  distanceKm: number,
  daysPerWeek: number,
) {
  const perTrip = calculateEmissions(currentMode, distanceKm) - calculateEmissions(alternativeMode, distanceKm);
  const perWeek = perTrip * 2 * Math.max(0, Math.min(7, daysPerWeek));
  return { perWeek: round(perWeek, 1), perMonth: round(perWeek * 4.33, 1) };
}

/** % improvement vs. a personal baseline. Positive = lower emissions. */
export function improvementPercent(baseline: number, current: number): number {
  if (!baseline || baseline <= 0) return 0;
  return round(((baseline - current) / baseline) * 100, 1);
}

/** Flags physically implausible entries before they are saved. */
export function validateTrip(mode: Mode, distanceKm: number): { ok: boolean; warning?: string } {
  if (!Number.isFinite(distanceKm) || distanceKm <= 0) return { ok: false, warning: "Distance must be more than 0 km." };
  if (ROAD_MODES.includes(mode) && distanceKm > MAX_ROAD_KM_PER_DAY)
    return { ok: false, warning: `Over ${MAX_ROAD_KM_PER_DAY} km in a day by road looks unlikely. Please check the distance.` };
  if ((mode === "walk" || mode === "cycle") && distanceKm > 80)
    return { ok: false, warning: "That's a very long walk or ride — please double-check." };
  if ((mode === "train" || mode === "metro") && distanceKm > MAX_RAIL_KM)
    return { ok: false, warning: "That rail distance looks too long." };
  if (mode === "flight" && distanceKm > MAX_FLIGHT_KM)
    return { ok: false, warning: "That flight distance looks too long." };
  return { ok: true };
}

/** Points reward low-carbon choices relative to driving a car; capped per day. */
export function pointsForTrip(mode: Mode, distanceKm: number): number {
  if (mode === "flight") return 0;
  const saved = (EMISSION_FACTORS.car - EMISSION_FACTORS[mode]) * distanceKm;
  return Math.max(0, Math.round(saved * 10) + (EMISSION_FACTORS[mode] === 0 ? 5 : 2));
}

export function capDailyPoints(points: number): number {
  return Math.min(DAILY_POINTS_CAP, Math.max(0, points));
}

/* ---------- Office habits ---------- */
// TODO: Replace with CEA grid emission factor and measured office data.
export const GRID_KG_PER_KWH = 0.71;
export type FoodWaste = "none" | "some" | "lots";
export interface HabitCheckIn {
  acHours: number;
  lightsLeftOn: boolean;
  pagesPrinted: number;
  foodWaste: FoodWaste;
}
export function habitEmissions(h: HabitCheckIn): number {
  const ac = h.acHours * 0.3 * GRID_KG_PER_KWH; // per-person share of a shared AC (~0.3 kWh/h)
  const lights = h.lightsLeftOn ? 0.5 : 0;
  const paper = h.pagesPrinted * 0.005;
  const food = h.foodWaste === "lots" ? 1.5 : h.foodWaste === "some" ? 0.5 : 0;
  return round(ac + lights + paper + food);
}

/** Classifies a daily footprint into low / medium / high. */
export type Co2Level = "low" | "medium" | "high";
export function co2Level(kgPerDay: number): Co2Level {
  if (kgPerDay < 2) return "low";
  if (kgPerDay < 5) return "medium";
  return "high";
}

/** Monthly baseline from the onboarding survey (round trip). */
export function baselineMonthly(mode: Mode, distanceKm: number, daysPerWeek: number): number {
  return round(calculateEmissions(mode, distanceKm) * 2 * daysPerWeek * 4.33, 1);
}
