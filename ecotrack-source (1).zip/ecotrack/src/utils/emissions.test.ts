import { describe, expect, it } from "vitest";
import { calculateEmissions, calculateSavings, improvementPercent, validateTrip, capDailyPoints } from "./emissions";

describe("emission engine", () => {
  it("uses the placeholder car factor of 0.17 kg/km", () => {
    expect(calculateEmissions("car", 10)).toBe(1.7);
  });
  it("walk and cycle are zero", () => {
    expect(calculateEmissions("walk", 5)).toBe(0);
    expect(calculateEmissions("cycle", 12)).toBe(0);
  });
  it("savings: car to metro, 10 km, 2 days a week", () => {
    // (1.7 - 0.3) * 2 trips * 2 days = 5.6 kg/week
    expect(calculateSavings("car", "metro", 10, 2).perWeek).toBe(5.6);
  });
  it("improvement vs baseline", () => {
    expect(improvementPercent(100, 80)).toBe(20);
    expect(improvementPercent(0, 10)).toBe(0);
  });
  it("flags more than 500 km a day by road", () => {
    expect(validateTrip("car", 501).ok).toBe(false);
    expect(validateTrip("car", 40).ok).toBe(true);
  });
  it("caps daily points at 100", () => {
    expect(capDailyPoints(250)).toBe(100);
  });
});
