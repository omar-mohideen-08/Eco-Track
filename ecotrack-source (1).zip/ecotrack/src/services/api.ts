/**
 * Service layer. Every function returns a Promise so the UI already handles
 * loading / error states. To connect a real REST API, replace the bodies with
 * fetch(`${BASE_URL}/...`) calls — the signatures can stay the same.
 *
 * PRIVACY: company-facing functions only ever return team / office / company
 * aggregates. Groups smaller than MIN_GROUP_SIZE are suppressed.
 */
import { EMPLOYEES, OFFICES, TEAMS, WEEKS, type Employee } from "@/data/seed";
import { improvementPercent } from "@/utils/emissions";

export const MIN_GROUP_SIZE = 5;
const delay = <T,>(v: T, ms = 350) => new Promise<T>((r) => setTimeout(() => r(v), ms));

const sum = (a: number[]) => a.reduce((s, n) => s + n, 0);
const r1 = (n: number) => Math.round(n * 10) / 10;

/** Weeks visible for the selected range (last N of 8). */
const slice = (arr: number[], weeks: number) => arr.slice(8 - weeks);

function aggregate(group: Employee[], weeks: number) {
  const active = group.filter((e) => e.participating);
  const commute = sum(active.map((e) => sum(slice(e.commute, weeks))));
  const travel = sum(active.map((e) => sum(slice(e.travel, weeks))));
  const baseline = sum(active.map((e) => e.baselineWeekly));
  const recent = sum(active.map((e) => ((e.commute[6] ?? 0) + (e.commute[7] ?? 0)) / 2));
  return {
    members: group.length,
    participants: active.length,
    commute: r1(commute),
    travel: r1(travel),
    total: r1(commute + travel),
    improvement: improvementPercent(baseline, recent),
    suppressed: active.length < MIN_GROUP_SIZE,
  };
}

export interface GroupRow extends ReturnType<typeof aggregate> { id: string; name: string }

export const api = {
  async getCompanyOverview(weeks = 8) {
    const active = EMPLOYEES.filter((e) => e.participating);
    const trend = WEEKS.map((week, i) => ({
      week,
      commute: r1(sum(active.map((e) => e.commute[i] ?? 0))),
      travel: r1(sum(active.map((e) => e.travel[i] ?? 0))),
    })).slice(8 - weeks);
    const thisMonth = sum(active.map((e) => sum(e.commute.slice(4)) + sum(e.travel.slice(4))));
    const lastMonth = sum(active.map((e) => sum(e.commute.slice(0, 4)) + sum(e.travel.slice(0, 4))));
    const saved = sum(active.map((e) => sum(slice(e.commute, weeks).map((c) => Math.max(0, e.baselineWeekly - c)))));
    return delay({
      totalThisMonth: r1(thisMonth),
      changePct: r1(((thisMonth - lastMonth) / lastMonth) * 100),
      participationPct: Math.round((active.length / EMPLOYEES.length) * 100),
      participants: active.length,
      headcount: EMPLOYEES.length,
      savedKg: r1(saved),
      trend: trend.map((t) => ({ ...t, total: r1(t.commute + t.travel) })),
    });
  },

  async getTeams(weeks = 8): Promise<GroupRow[]> {
    return delay(TEAMS.map((t) => ({ id: t, name: t, ...aggregate(EMPLOYEES.filter((e) => e.team === t), weeks) })));
  },

  async getOffices(weeks = 8): Promise<GroupRow[]> {
    return delay(OFFICES.map((o) => ({ id: o.id, name: o.name, ...aggregate(EMPLOYEES.filter((e) => e.officeId === o.id), weeks) })));
  },

  async getScope3(weeks = 8) {
    const active = EMPLOYEES.filter((e) => e.participating);
    const cat7 = sum(active.map((e) => sum(slice(e.commute, weeks))));
    const cat6 = sum(active.map((e) => sum(slice(e.travel, weeks))));
    // Aggregate commute mode split (company-wide estimate)
    const split = { car: 0.38, cab: 0.17, "two-wheeler": 0.16, bus: 0.12, metro: 0.1, "auto-rickshaw": 0.07 };
    return delay({
      cat6: r1(cat6),
      cat7: r1(cat7),
      weekly: WEEKS.map((week, i) => ({
        week,
        cat6: r1(sum(active.map((e) => e.travel[i] ?? 0))),
        cat7: r1(sum(active.map((e) => e.commute[i] ?? 0))),
      })).slice(8 - weeks),
      commuteModes: Object.entries(split).map(([mode, s]) => ({ mode, kg: r1(cat7 * s) })),
    });
  },

  /** Individual leaderboard for the employee app (opt-in display names only). */
  async getIndividualLeaderboard() {
    return delay(
      EMPLOYEES.filter((e) => e.participating).map((e) => ({
        id: e.id,
        name: `${e.name.split(" ")[0]} ${e.name.split(" ")[1]?.[0] ?? ""}.`,
        sub: e.team,
        improvement: improvementPercent(e.baselineWeekly, ((e.commute[6] ?? 0) + (e.commute[7] ?? 0)) / 2),
      })),
    );
  },
};
