import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Building2, ShieldCheck, Smartphone } from "lucide-react";
import { Logo, ThemeToggle } from "@/components/eco/primitives";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "EcoTrack — Opt-in workplace carbon tracking" },
      { name: "description", content: "Turn commuting, business travel and office habits into Scope 3 data for SEBI BRSR reporting." },
      { property: "og:title", content: "EcoTrack — Opt-in workplace carbon tracking" },
      { property: "og:description", content: "Scope 3 commute and travel data for Indian companies, with privacy by design." },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5">
        <Logo />
        <ThemeToggle />
      </header>
      <main className="mx-auto max-w-6xl px-5 pb-16">
        <section className="animate-rise py-10 md:py-16">
          <p className="mb-3 inline-flex items-center gap-2 rounded-full bg-secondary px-3 py-1 text-xs font-semibold text-secondary-foreground">
            <ShieldCheck className="size-3.5" aria-hidden /> DPDP Act 2023 ready · Opt-in only
          </p>
          <h1 className="max-w-3xl text-4xl font-extrabold leading-[1.05] md:text-6xl">
            Small switches. <span className="text-primary">Measurable</span> Scope 3.
          </h1>
          <p className="mt-4 max-w-xl text-lg text-muted-foreground">
            EcoTrack turns commutes, business travel and office habits into CO₂ data your team is proud of — and your BRSR report needs.
          </p>
        </section>
        <div className="grid gap-5 md:grid-cols-2">
          <PortalCard to="/login" icon={Smartphone} title="Employee app" body="Log a trip in two taps, see your footprint shrink, and climb the improvement leaderboard." cta="Open employee app" />
          <div className="rounded-3xl border border-dashed bg-card p-7">
            <span className="grid size-12 place-items-center rounded-2xl bg-muted"><Building2 className="size-6" aria-hidden /></span>
            <h2 className="mt-5 text-2xl font-bold">Company dashboard</h2>
            <p className="mt-2 text-muted-foreground">Team-level emissions, GHG Category 6 &amp; 7 split, challenges and BRSR-ready exports.</p>
            <span className="mt-5 inline-block text-sm font-semibold text-muted-foreground">Coming next</span>
          </div>
        </div>
        <p className="mt-8 text-sm text-muted-foreground">Demo company: Acme Tech Park, Chennai · 40 employees · 8 weeks of sample data.</p>
      </main>
    </div>
  );
}

function PortalCard({ to, icon: Icon, title, body, cta }: { to: "/login"; icon: typeof Smartphone; title: string; body: string; cta: string }) {
  return (
    <Link to={to} className="group animate-rise rounded-3xl border bg-card p-7 shadow-card transition-all hover:-translate-y-1 hover:border-primary/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
      <span className="grid size-12 place-items-center rounded-2xl bg-hero text-primary-foreground"><Icon className="size-6" aria-hidden /></span>
      <h2 className="mt-5 text-2xl font-bold">{title}</h2>
      <p className="mt-2 text-muted-foreground">{body}</p>
      <span className="mt-5 inline-flex items-center gap-1 font-semibold text-primary">{cta} <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden /></span>
    </Link>
  );
}
