import { createFileRoute, Link, Navigate, Outlet } from "@tanstack/react-router";
import { Home, Lightbulb, Plus, Trophy, UserRound } from "lucide-react";
import { Logo, ThemeToggle } from "@/components/eco/primitives";
import { useApp } from "@/store/app-store";

export const Route = createFileRoute("/app")({ component: EmployeeLayout });

const NAV = [
  { to: "/app", label: "Home", icon: Home, exact: true },
  { to: "/app/tips", label: "Tips", icon: Lightbulb },
  { to: "/app/leaderboard", label: "Ranks", icon: Trophy },
  { to: "/app/profile", label: "Profile", icon: UserRound },
] as const;

/** Mobile-first shell with bottom tabs and a floating "+ Log" button. */
function EmployeeLayout() {
  const user = useApp((s) => s.user);
  if (!user) return <Navigate to="/login" />;
  return (
    <div className="mx-auto min-h-screen max-w-2xl pb-28">
      <header className="sticky top-0 z-20 flex items-center justify-between border-b bg-background/85 px-5 py-3 backdrop-blur">
        <Link to="/app" aria-label="EcoTrack home"><Logo /></Link>
        <ThemeToggle />
      </header>
      <main className="px-4 pt-5"><Outlet /></main>
      <nav aria-label="Main" className="fixed inset-x-0 bottom-0 z-30 border-t bg-card/95 backdrop-blur">
        <ul className="relative mx-auto grid max-w-2xl grid-cols-5 items-end px-2 pb-[max(env(safe-area-inset-bottom),0.5rem)] pt-2">
          {NAV.slice(0, 2).map((n) => <Tab key={n.to} {...n} />)}
          <li className="flex justify-center">
            <Link to="/app/log" aria-label="Log a trip" className="-mt-8 flex size-16 flex-col items-center justify-center rounded-full bg-hero text-primary-foreground shadow-float ring-4 ring-background transition-transform hover:scale-105 active:scale-95">
              <Plus className="size-6" aria-hidden /><span className="text-[10px] font-bold">Log</span>
            </Link>
          </li>
          {NAV.slice(2).map((n) => <Tab key={n.to} {...n} />)}
        </ul>
      </nav>
    </div>
  );
}

function Tab({ to, label, icon: Icon, ...rest }: { to: string; label: string; icon: typeof Home; exact?: boolean }) {
  return (
    <li>
      <Link to={to} activeOptions={{ exact: "exact" in rest && !!rest.exact }}
        className="flex flex-col items-center gap-0.5 rounded-xl py-1.5 text-xs text-muted-foreground transition-colors data-[status=active]:font-semibold data-[status=active]:text-primary">
        <Icon className="size-5" aria-hidden />{label}
      </Link>
    </li>
  );
}
