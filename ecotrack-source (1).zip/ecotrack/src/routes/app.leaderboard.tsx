import { createFileRoute } from "@tanstack/react-router";
import { Info } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LeaderboardTable } from "@/components/eco/cards";
import { Card, CardSkeleton, ErrorState, PageTitle } from "@/components/eco/primitives";
import { useAsync } from "@/hooks/use-async";
import { api } from "@/services/api";
import { selectBaselineMonthly, useApp } from "@/store/app-store";
import { improvementPercent } from "@/utils/emissions";
import { sumKg } from "@/utils/stats";

export const Route = createFileRoute("/app/leaderboard")({
  head: () => ({ meta: [{ title: "Leaderboard — EcoTrack" }, { name: "description", content: "Ranked by improvement, not absolute emissions." }, { property: "og:title", content: "Leaderboard — EcoTrack" }, { property: "og:description", content: "Fair, improvement-based ranking." }] }),
  component: Leaderboard,
});

function Leaderboard() {
  const people = useAsync(() => api.getIndividualLeaderboard());
  const teams = useAsync(() => api.getTeams());
  const user = useApp((s) => s.user);
  const visible = useApp((s) => s.consent.leaderboard);
  const logs = useApp((s) => s.logs);
  const baseline = useApp(selectBaselineMonthly);
  const mine = improvementPercent(baseline, sumKg(logs, 29));

  const rows = (people.data ?? []).map((p) =>
    p.id === "e0" ? { ...p, name: visible ? `${user?.name ?? "You"}` : "You (hidden from others)", improvement: mine, highlight: true } : p,
  );

  return (
    <div>
      <PageTitle title="Leaderboard" />
      <p className="mb-4 flex items-start gap-2 rounded-xl bg-secondary p-3 text-sm text-secondary-foreground">
        <Info className="mt-0.5 size-4 shrink-0" aria-hidden /> Ranked by % reduction vs. each person's own baseline — so a long commute never counts against you.
      </p>
      <Tabs defaultValue="people">
        <TabsList className="grid w-full grid-cols-2"><TabsTrigger value="people">Individuals</TabsTrigger><TabsTrigger value="teams">Teams</TabsTrigger></TabsList>
        <TabsContent value="people">
          <Card>{people.loading ? <CardSkeleton h={400} /> : people.error ? <ErrorState onRetry={people.retry} /> : <LeaderboardTable rows={rows} caption="Individual leaderboard" />}</Card>
        </TabsContent>
        <TabsContent value="teams">
          <Card>{teams.loading ? <CardSkeleton h={240} /> : teams.error ? <ErrorState onRetry={teams.retry} /> :
            <LeaderboardTable caption="Team leaderboard" rows={(teams.data ?? []).map((t) => ({ id: t.id, name: t.name, sub: `${t.participants} participants`, improvement: t.improvement, highlight: t.name === user?.team }))} />}</Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
