import { createFileRoute, Navigate, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, ArrowRight, ShieldCheck, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { ConsentToggle } from "@/components/eco/cards";
import { ModeSelector } from "@/components/eco/ModeSelector";
import { celebrate, CountUp, Logo } from "@/components/eco/primitives";
import { DEFAULT_BASELINE, useApp, type Baseline } from "@/store/app-store";
import { baselineMonthly } from "@/utils/emissions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/onboarding")({
  head: () => ({ meta: [{ title: "Get started — EcoTrack" }, { name: "description", content: "Set your starting footprint in two minutes." }, { property: "og:title", content: "Get started — EcoTrack" }, { property: "og:description", content: "Two-minute onboarding." }] }),
  component: Onboarding,
});

const STEPS = ["Consent", "Your commute", "Your start"];
const VEHICLES = ["Petrol hatchback", "Diesel SUV", "CNG car", "Electric car", "Petrol scooter", "Electric scooter", "None"];

function Onboarding() {
  const user = useApp((s) => s.user);
  const complete = useApp((s) => s.completeOnboarding);
  const nav = useNavigate();
  const [step, setStep] = useState(0);
  const [auto, setAuto] = useState(false);
  const [b, setB] = useState<Baseline>(DEFAULT_BASELINE);
  if (!user) return <Navigate to="/login" />;
  const monthly = baselineMonthly(b.mode, b.distanceKm, b.daysPerWeek);

  const next = () => {
    if (step === 1) setTimeout(celebrate, 300);
    if (step < 2) setStep(step + 1);
    else { complete(b, auto); nav({ to: "/app" }); }
  };

  return (
    <main className="mx-auto flex min-h-screen max-w-lg flex-col px-5 py-6">
      <Logo />
      <ol className="mt-6 flex gap-2" aria-label="Onboarding progress">
        {STEPS.map((s, i) => (
          <li key={s} className="flex-1" aria-current={i === step ? "step" : undefined}>
            <div className={cn("h-1.5 rounded-full transition-colors", i <= step ? "bg-primary" : "bg-muted")} />
            <span className={cn("mt-1 block text-xs", i === step ? "font-semibold" : "text-muted-foreground")}>{s}</span>
          </li>
        ))}
      </ol>

      <div key={step} className="mt-6 flex-1 animate-rise">
        {step === 0 && (
          <>
            <h1 className="text-2xl font-bold">Hi {user.name.split(" ")[0]}, your data stays yours</h1>
            <div className="mt-4 rounded-2xl border bg-secondary/60 p-4 text-sm">
              <p className="flex items-center gap-2 font-semibold"><ShieldCheck className="size-4 text-primary" aria-hidden /> Privacy notice (DPDP Act 2023)</p>
              <ul className="mt-2 list-disc space-y-1 pl-5 text-muted-foreground">
                <li>Footprint tracking is opt-in. You can pause it anytime.</li>
                <li>Your employer sees only team totals (groups of 5+), never your trips.</li>
                <li>You can download or delete your data from Settings.</li>
              </ul>
            </div>
            <ConsentToggle id="auto" label="Automatic trip detection" description="Suggest trips from phone motion so you just confirm them. Off by default." checked={auto} onChange={setAuto} />
          </>
        )}
        {step === 1 && (
          <div className="space-y-6">
            <h1 className="text-2xl font-bold">How do you usually get to work?</h1>
            <div>
              <label htmlFor="dist" className="text-sm font-semibold">Home to office (one way)</label>
              <div className="mt-2 flex items-center gap-3">
                <Slider aria-label="Distance in km" value={[b.distanceKm]} min={1} max={60} step={1} onValueChange={([v]) => setB({ ...b, distanceKm: v ?? b.distanceKm })} className="flex-1" />
                <Input id="dist" type="number" min={1} max={200} value={b.distanceKm} onChange={(e) => setB({ ...b, distanceKm: Math.max(0, Number(e.target.value)) })} className="w-20" />
                <span className="text-sm text-muted-foreground">km</span>
              </div>
            </div>
            <div>
              <p className="mb-2 text-sm font-semibold">Usual commute mode</p>
              <ModeSelector value={b.mode} onChange={(mode) => setB({ ...b, mode })} compact />
            </div>
            <div>
              <label htmlFor="veh" className="text-sm font-semibold">Vehicle type</label>
              <select id="veh" value={b.vehicle} onChange={(e) => setB({ ...b, vehicle: e.target.value })} className="mt-1.5 h-10 w-full rounded-md border bg-card px-3 text-sm">
                {VEHICLES.map((v) => <option key={v}>{v}</option>)}
              </select>
            </div>
            <div>
              <p className="mb-2 text-sm font-semibold">Days in office per week</p>
              <div className="flex gap-2" role="radiogroup" aria-label="Days in office">
                {[1, 2, 3, 4, 5, 6].map((d) => (
                  <button key={d} role="radio" aria-checked={b.daysPerWeek === d} onClick={() => setB({ ...b, daysPerWeek: d })}
                    className={cn("size-11 rounded-xl border-2 font-semibold", b.daysPerWeek === d ? "border-primary bg-primary text-primary-foreground" : "bg-card")}>{d}</button>
                ))}
              </div>
            </div>
          </div>
        )}
        {step === 2 && (
          <div className="pt-6 text-center">
            <Sparkles className="mx-auto size-10 text-primary" aria-hidden />
            <p className="mt-4 text-muted-foreground">Your starting footprint is</p>
            <p className="font-display text-6xl font-extrabold text-primary"><CountUp value={monthly} decimals={1} /></p>
            <p className="font-semibold">kg CO₂ / month</p>
            <p className="mx-auto mt-4 max-w-xs text-sm text-muted-foreground">This is your personal baseline. We'll celebrate every % you cut from here — it's you vs. you, not you vs. colleagues.</p>
          </div>
        )}
      </div>

      <div className="mt-8 flex gap-3">
        {step > 0 && <Button variant="outline" className="h-12" onClick={() => setStep(step - 1)} aria-label="Back"><ArrowLeft className="size-4" /></Button>}
        <Button className="h-12 flex-1" onClick={next}>{step === 2 ? "Go to my dashboard" : "Continue"} <ArrowRight className="size-4" /></Button>
      </div>
    </main>
  );
}
