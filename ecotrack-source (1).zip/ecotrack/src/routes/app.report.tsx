import { createFileRoute } from "@tanstack/react-router";
import { Share2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Logo, PageTitle } from "@/components/eco/primitives";
import { selectBaselineMonthly, useApp } from "@/store/app-store";
import { MODE_LABELS } from "@/utils/emissions";
import { modeBreakdown, streak, sumKg } from "@/utils/stats";

export const Route = createFileRoute("/app/report")({
  head: () => ({ meta: [{ title: "Weekly report — EcoTrack" }, { name: "description", content: "Your week in review." }, { property: "og:title", content: "Weekly report — EcoTrack" }, { property: "og:description", content: "Shareable weekly summary." }] }),
  component: Report,
});

function Report() {
  const logs = useApp((s) => s.logs);
  const user = useApp((s) => s.user);
  const baselineWeek = useApp(selectBaselineMonthly) / 4.33;
  const week = sumKg(logs, 6);
  const last = sumKg(logs, 13, 7);
  const saved = Math.max(0, Math.round((baselineWeek - week) * 10) / 10);
  const green = modeBreakdown(logs, 7).at(-1);
  const trips = logs.filter((l) => l.date >= new Date(Date.now() - 6 * 864e5).toISOString().slice(0, 10)).length;
  const text = `This week I saved ${saved} kg CO₂ vs my baseline with EcoTrack 🌱 ${streak(logs)}-day streak!`;

  const share = async () => {
    if (navigator.share) { try { await navigator.share({ title: "My EcoTrack week", text }); } catch { /* cancelled */ } }
    else { await navigator.clipboard.writeText(text); toast.success("Copied to clipboard"); }
  };

  return (
    <div>
      <PageTitle title="Weekly report" />
      <article aria-label="Shareable weekly summary" className="relative overflow-hidden rounded-3xl bg-hero p-6 text-primary-foreground shadow-float">
        <div className="absolute -right-10 -top-10 size-40 rounded-full bg-accent/30 blur-2xl" aria-hidden />
        <Logo className="text-primary-foreground" />
        <p className="mt-6 text-sm opacity-85">{user?.name}'s week</p>
        <p className="font-display text-5xl font-extrabold">{saved} kg</p>
        <p className="opacity-90">CO₂ saved vs. baseline</p>
        <dl className="mt-6 grid grid-cols-3 gap-3 text-center">
          {[["This week", `${week} kg`], ["Last week", `${last} kg`], ["Trips", trips]].map(([k, v]) => (
            <div key={k} className="rounded-2xl bg-primary-foreground/15 p-3"><dt className="text-xs opacity-80">{k}</dt><dd className="font-bold">{v}</dd></div>
          ))}
        </dl>
        {green && <p className="mt-4 text-sm opacity-90">Lowest-impact mode used: <strong>{MODE_LABELS[green.mode]}</strong></p>}
      </article>
      <Button className="mt-4 h-12 w-full" onClick={share}><Share2 className="size-4" /> Share my week</Button>
    </div>
  );
}
