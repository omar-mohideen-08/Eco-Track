import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import { toast } from "sonner";
import { TipCard } from "@/components/eco/cards";
import { celebrate, PageTitle } from "@/components/eco/primitives";
import { useApp } from "@/store/app-store";
import { generateTips } from "@/utils/stats";

export const Route = createFileRoute("/app/tips")({
  head: () => ({ meta: [{ title: "Your best switch — EcoTrack" }, { name: "description", content: "Personalised tips to cut your footprint." }, { property: "og:title", content: "Tips — EcoTrack" }, { property: "og:description", content: "Personalised low-carbon switches." }] }),
  component: Tips,
});

function Tips() {
  const logs = useApp((s) => s.logs);
  const baseline = useApp((s) => s.baseline);
  const accepted = useApp((s) => s.acceptedTips);
  const accept = useApp((s) => s.acceptTip);
  const tips = useMemo(() => generateTips(logs, baseline), [logs, baseline]);
  return (
    <div className="space-y-3">
      <PageTitle title="Tips for you" sub="Based on your biggest emission source this month." />
      {tips.map((t, i) => (
        <TipCard key={t.id} tip={t} featured={i === 0} accepted={accepted.includes(t.id)}
          onAccept={() => { accept(t.id); celebrate(); toast.success("Challenge accepted — we'll cheer you on!"); }} />
      ))}
    </div>
  );
}
