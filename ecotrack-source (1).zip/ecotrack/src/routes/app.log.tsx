import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { AlertTriangle, Check, Home, Minus, Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ModeSelector } from "@/components/eco/ModeSelector";
import { Card, Co2Badge, PageTitle } from "@/components/eco/primitives";
import { useApp } from "@/store/app-store";
import { calculateEmissions, co2Level, habitEmissions, MODE_LABELS, validateTrip, type FoodWaste, type Mode } from "@/utils/emissions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/app/log")({
  head: () => ({ meta: [{ title: "Quick log — EcoTrack" }, { name: "description", content: "Log a trip or office habit in two taps." }, { property: "og:title", content: "Quick log — EcoTrack" }, { property: "og:description", content: "Two-tap logging." }] }),
  component: QuickLog,
});

function QuickLog() {
  return (
    <div>
      <PageTitle title="Quick log" sub="Two taps and you're done." />
      <Tabs defaultValue="trip">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="trip">Trip</TabsTrigger>
          <TabsTrigger value="habits">Office habits</TabsTrigger>
        </TabsList>
        <TabsContent value="trip"><TripForm /></TabsContent>
        <TabsContent value="habits"><HabitsForm /></TabsContent>
      </Tabs>
    </div>
  );
}

function TripForm() {
  const baseline = useApp((s) => s.baseline);
  const addLog = useApp((s) => s.addLog);
  const nav = useNavigate();
  const [mode, setMode] = useState<Mode | null>(null);
  const [km, setKm] = useState(baseline.distanceKm);
  const kg = mode ? calculateEmissions(mode, km) : 0;
  const check = mode ? validateTrip(mode, km) : { ok: false };
  const max = mode === "flight" ? 3000 : mode === "train" ? 1500 : 100;

  const save = () => {
    if (!mode || !check.ok) return;
    addLog(mode, km);
    toast.success(`Logged ${MODE_LABELS[mode]} · ${km} km · ${kg} kg CO₂`);
    nav({ to: "/app" });
  };

  return (
    <div className="mt-4 space-y-4">
      <ModeSelector value={mode} onChange={(m) => { setMode(m); if (m === "flight" && km < 100) setKm(290); }} />
      <Card className={cn("space-y-3 transition-opacity", !mode && "pointer-events-none opacity-50")} aria-disabled={!mode}>
        <div className="flex items-center justify-between">
          <label htmlFor="km" className="font-semibold">Distance</label>
          <button type="button" onClick={() => setKm(baseline.distanceKm)} className="inline-flex items-center gap-1 rounded-full bg-secondary px-3 py-1 text-xs font-semibold text-secondary-foreground">
            <Home className="size-3" aria-hidden /> Same as usual commute ({baseline.distanceKm} km)
          </button>
        </div>
        <div className="flex items-center gap-3">
          <Slider aria-label="Distance in km" value={[Math.min(km, max)]} min={0.5} max={max} step={0.5} onValueChange={([v]) => setKm(v ?? km)} className="flex-1" />
          <Input id="km" type="number" inputMode="decimal" min={0} value={km} onChange={(e) => setKm(Number(e.target.value))} className="w-24" />
          <span className="text-sm text-muted-foreground">km</span>
        </div>
        {mode && !check.ok && check.warning && (
          <p role="alert" className="flex items-center gap-2 text-sm font-medium text-co2-high"><AlertTriangle className="size-4" aria-hidden />{check.warning}</p>
        )}
      </Card>
      <div aria-live="polite" className="flex items-center justify-between rounded-2xl bg-secondary p-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">CO₂ preview</p>
          <p className="font-display text-3xl font-bold">{kg} <span className="text-base">kg</span></p>
        </div>
        {mode && <Co2Badge level={co2Level(kg)} />}
      </div>
      <Button className="h-12 w-full text-base" disabled={!mode || !check.ok} onClick={save}><Check className="size-5" /> Save trip</Button>
    </div>
  );
}

function Stepper({ label, value, onChange, step = 1, unit }: { label: string; value: number; onChange: (n: number) => void; step?: number; unit: string }) {
  return (
    <div className="flex items-center justify-between py-3">
      <span className="font-semibold">{label}</span>
      <div className="flex items-center gap-2">
        <Button size="icon" variant="outline" aria-label={`Decrease ${label}`} onClick={() => onChange(Math.max(0, value - step))}><Minus className="size-4" /></Button>
        <span className="w-16 text-center tabular-nums" aria-live="polite">{value} {unit}</span>
        <Button size="icon" variant="outline" aria-label={`Increase ${label}`} onClick={() => onChange(value + step)}><Plus className="size-4" /></Button>
      </div>
    </div>
  );
}

function HabitsForm() {
  const addHabit = useApp((s) => s.addHabit);
  const [acHours, setAc] = useState(6);
  const [lightsLeftOn, setLights] = useState(false);
  const [pagesPrinted, setPages] = useState(0);
  const [foodWaste, setFood] = useState<FoodWaste>("none");
  const kg = habitEmissions({ acHours, lightsLeftOn, pagesPrinted, foodWaste });
  return (
    <Card className="mt-4 divide-y">
      <Stepper label="AC usage today" value={acHours} onChange={setAc} unit="hrs" />
      <div className="flex items-center justify-between py-3">
        <label htmlFor="lights" className="font-semibold">Lights left on after leaving</label>
        <Switch id="lights" checked={lightsLeftOn} onCheckedChange={setLights} />
      </div>
      <Stepper label="Pages printed" value={pagesPrinted} onChange={setPages} step={5} unit="pg" />
      <div className="py-3">
        <p className="mb-2 font-semibold">Food waste at lunch</p>
        <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label="Food waste">
          {(["none", "some", "lots"] as FoodWaste[]).map((f) => (
            <button key={f} role="radio" aria-checked={foodWaste === f} onClick={() => setFood(f)}
              className={cn("rounded-xl border-2 py-2 text-sm font-semibold capitalize", foodWaste === f ? "border-primary bg-primary text-primary-foreground" : "bg-card")}>{f}</button>
          ))}
        </div>
      </div>
      <div className="flex items-center justify-between pt-4">
        <p aria-live="polite"><span className="font-display text-2xl font-bold">{kg}</span> kg CO₂</p>
        <Button onClick={() => { addHabit({ acHours, lightsLeftOn, pagesPrinted, foodWaste }); toast.success("Office check-in saved — thanks!"); }}>Save check-in</Button>
      </div>
    </Card>
  );
}
