import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { Award, CalendarDays, ChevronRight, Flame, Radar, Sun, TrendingDown } from "lucide-react";
import { StatCard } from "@/components/eco/StatCard";
import { ModeDonut, WeeklyModeBar } from "@/components/eco/EmissionChart";
import { Card, celebrate, ProgressRing } from "@/components/eco/primitives";
import { selectBaselineMonthly, useApp } from "@/store/app-store";
import { co2Level, improvementPercent, type Mode } from "@/utils/emissions";
import { modeBreakdown, streak, sumKg, totalPoints, weeklyByMode } from "@/utils/stats";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/app/")({
  head: () => ({ meta: [{ title: "My footprint — EcoTrack" }, { name: "description", content: "Your personal carbon footprint dashboard." }, { property: "og:title", content: "My footprint — EcoTrack" }, { property: "og:description", content: "Track your commute footprint." }] }),
  component: Home,
});

function Home() {
  const { logs, user, detected } = useApp();
  const baseline = useApp(selectBaselineMonthly);
  const today = sumKg(logs, 0);
  const week = sumKg(logs, 6);
  const lastWeek = sumKg(logs, 13, 7);
  const month = sumKg(logs, 29);
  const improvement = improvementPercent(baseline, month);
  const days = streak(logs);
  const points = totalPoints(logs);
  const weekly = useMemo(() => weeklyByMode(logs), [logs]);
  const modes = useMemo(() => [...new Set(logs.map((l) => l.mode))] as Mode[], [logs]);
  const donut = useMemo(() => modeBreakdown(logs), [logs]);

  const badges = [
    { name: "First log", earned: logs.length > 0 },
    { name: "5-day streak", earned: days >= 5 },
    { name: "Metro maven", earned: logs.filter((l) => l.mode === "metro").length >= 10 },
    { name: "10% better", earned: improvement >= 10 },
    { name: "Car-free week", earned: false },
  ];

  return (
    <div className="space-y-4">
      <div>
        <p className="text-sm text-muted-foreground">Vanakkam,</p>
        <h1 className="text-2xl font-bold">{user?.name.split(" ")[0]} 👋</h1>
      </div>

      {detected.length > 0 && (
        <Link to="/app/trips" className="flex items-center gap-3 rounded-2xl border border-primary/30 bg-accent/30 p-3 text-sm font-medium">
          <Radar className="size-5 text-primary" aria-hidden />
          <span className="flex-1">{detected.length} detected trip{detected.length > 1 ? "s" : ""} waiting for review</span>
          <ChevronRight className="size-4" aria-hidden />
        </Link>
      )}

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
        <StatCard label="Today" value={today} unit="kg" icon={Sun} level={co2Level(today)} />
        <StatCard label="This week" value={week} unit="kg" icon={CalendarDays} change={lastWeek ? Math.round(((week - lastWeek) / lastWeek) * 100) : undefined} changeLabel="vs last wk" />
        <StatCard label="This month" value={month} unit="kg" icon={TrendingDown} className="col-span-2 md:col-span-1" level={co2Level(month / 22)} />
      </div>

      <Card className="flex items-center gap-5">
        <ProgressRing value={improvement} label="Improvement versus baseline" sub="vs baseline" />
        <div className="flex-1">
          <h2 className="font-bold">{improvement > 0 ? "You're beating your baseline!" : "Let's start shrinking"}</h2>
          <p className="mt-1 text-sm text-muted-foreground">Baseline {baseline} kg/month · Now {month} kg</p>
          <button onClick={celebrate} className="mt-3 inline-flex items-center gap-2 rounded-full bg-co2-medium/15 px-3 py-1.5 text-sm font-semibold text-co2-medium" aria-label={`${days} day streak. Celebrate`}>
            <Flame className="size-4" aria-hidden /> {days}-day streak
          </button>
          <p className="mt-2 text-xs text-muted-foreground">{points.toLocaleString("en-IN")} green points</p>
        </div>
      </Card>

      <Card>
        <h2 className="mb-3 font-bold">Last 7 days</h2>
        <WeeklyModeBar data={weekly} modes={modes} />
      </Card>

      <Card>
        <h2 className="mb-3 font-bold">Where your CO₂ comes from (30 days)</h2>
        <ModeDonut data={donut} />
      </Card>

      <Card>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-bold">Badges</h2>
          <Link to="/app/rewards" className="text-sm font-semibold text-primary">Rewards →</Link>
        </div>
        <ul className="flex gap-3 overflow-x-auto pb-1">
          {badges.map((b) => (
            <li key={b.name} className={cn("flex w-20 shrink-0 flex-col items-center gap-1 text-center text-xs", !b.earned && "opacity-45")}>
              <span className={cn("grid size-14 place-items-center rounded-2xl", b.earned ? "bg-hero text-primary-foreground" : "bg-muted")}><Award className="size-6" aria-hidden /></span>
              {b.name}<span className="sr-only">{b.earned ? "earned" : "locked"}</span>
            </li>
          ))}
        </ul>
      </Card>

      <Link to="/app/report" className="block rounded-2xl bg-hero p-5 text-primary-foreground shadow-card">
        <p className="text-xs font-semibold uppercase tracking-wider opacity-80">Weekly report ready</p>
        <p className="mt-1 text-lg font-bold">See your week in review →</p>
      </Link>
    </div>
  );
}
