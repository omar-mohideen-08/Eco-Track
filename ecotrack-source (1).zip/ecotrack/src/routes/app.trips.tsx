import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Check, MapPin, Pencil, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MODE_ICONS, ModeSelector } from "@/components/eco/ModeSelector";
import { Card, EmptyState, PageTitle } from "@/components/eco/primitives";
import { useApp } from "@/store/app-store";
import { calculateEmissions, MODE_LABELS, type Mode } from "@/utils/emissions";
import type { DetectedTrip } from "@/data/seed";

export const Route = createFileRoute("/app/trips")({
  head: () => ({ meta: [{ title: "Detected trips — EcoTrack" }, { name: "description", content: "Review automatically detected trips." }, { property: "og:title", content: "Detected trips — EcoTrack" }, { property: "og:description", content: "Confirm, edit or dismiss trips." }] }),
  component: Trips,
});

function Trips() {
  const detected = useApp((s) => s.detected);
  const autoDetect = useApp((s) => s.consent.autoDetect);
  return (
    <div>
      <PageTitle title="Detected trips" sub="Preview of upcoming automatic detection — nothing is saved until you confirm." />
      {!autoDetect && <p className="mb-4 rounded-xl bg-muted p-3 text-sm">Automatic detection is off. You can turn it on in Profile → Privacy.</p>}
      {detected.length === 0 ? (
        <EmptyState title="All caught up" body="No trips to review. New detections will show up here." />
      ) : (
        <ul className="space-y-3">{detected.map((t) => <TripRow key={t.id} trip={t} />)}</ul>
      )}
    </div>
  );
}

function TripRow({ trip }: { trip: DetectedTrip }) {
  const resolve = useApp((s) => s.resolveDetected);
  const [editing, setEditing] = useState(false);
  const [mode, setMode] = useState<Mode>(trip.mode);
  const [km, setKm] = useState(trip.km);
  const Icon = MODE_ICONS[mode];
  return (
    <li>
      <Card className="p-4">
        <div className="flex items-start gap-3">
          <span className="grid size-10 place-items-center rounded-xl bg-secondary"><Icon className="size-5" aria-hidden /></span>
          <div className="flex-1">
            <p className="font-semibold">{MODE_LABELS[mode]} · {km} km · {calculateEmissions(mode, km)} kg CO₂</p>
            <p className="flex items-center gap-1 text-sm text-muted-foreground"><MapPin className="size-3" aria-hidden />{trip.from} → {trip.to}</p>
            <p className="text-xs text-muted-foreground">{trip.time}</p>
          </div>
        </div>
        {editing && (
          <div className="mt-3 space-y-3">
            <ModeSelector value={mode} onChange={setMode} compact />
            <label className="flex items-center gap-2 text-sm">Distance <Input type="number" value={km} onChange={(e) => setKm(Number(e.target.value))} className="w-24" /> km</label>
          </div>
        )}
        <div className="mt-3 flex gap-2">
          <Button size="sm" className="flex-1" onClick={() => { resolve(trip.id, "confirm", { mode, km }); toast.success("Trip confirmed"); }}><Check className="size-4" /> Confirm</Button>
          <Button size="sm" variant="outline" onClick={() => setEditing(!editing)} aria-expanded={editing}><Pencil className="size-4" /> Edit</Button>
          <Button size="sm" variant="ghost" onClick={() => resolve(trip.id, "dismiss")}><X className="size-4" /> Dismiss</Button>
        </div>
      </Card>
    </li>
  );
}
