import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ChevronRight, Download, FileText, Gift, LogOut, Radar, ShieldCheck, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { ConsentToggle } from "@/components/eco/cards";
import { Card, PageTitle } from "@/components/eco/primitives";
import { useApp } from "@/store/app-store";

export const Route = createFileRoute("/app/profile")({
  head: () => ({ meta: [{ title: "Privacy & settings — EcoTrack" }, { name: "description", content: "Manage consent, download or delete your data." }, { property: "og:title", content: "Privacy & settings — EcoTrack" }, { property: "og:description", content: "Your data, your control." }] }),
  component: Profile,
});

function Profile() {
  const s = useApp();
  const nav = useNavigate();

  const download = () => {
    const blob = new Blob([JSON.stringify({ user: s.user, baseline: s.baseline, consent: s.consent, trips: s.logs, officeHabits: s.habits }, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "ecotrack-my-data.json";
    a.click();
    URL.revokeObjectURL(a.href);
    toast.success("Your data has been downloaded");
  };

  return (
    <div className="space-y-4">
      <PageTitle title={s.user?.name ?? "Profile"} sub={`${s.user?.email} · ${s.user?.team}`} />
      <Card className="divide-y p-0">
        {[
          { to: "/app/trips", icon: Radar, label: "Detected trips", badge: s.detected.length },
          { to: "/app/rewards", icon: Gift, label: "Rewards" },
          { to: "/app/report", icon: FileText, label: "Weekly report" },
        ].map((l) => (
          <Link key={l.to} to={l.to} className="flex items-center gap-3 px-5 py-4 hover:bg-muted/60">
            <l.icon className="size-5 text-primary" aria-hidden /><span className="flex-1 font-medium">{l.label}</span>
            {!!l.badge && <span className="rounded-full bg-accent px-2 text-xs font-bold text-accent-foreground">{l.badge}</span>}
            <ChevronRight className="size-4 text-muted-foreground" aria-hidden />
          </Link>
        ))}
      </Card>

      <Card>
        <h2 className="flex items-center gap-2 font-bold"><ShieldCheck className="size-5 text-primary" aria-hidden /> Privacy & consent</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          EcoTrack processes your data under the Digital Personal Data Protection (DPDP) Act, 2023. Footprint tracking is opt-in, used only for sustainability reporting,
          and your employer only sees team totals for groups of at least 5 people — never your individual trips.
        </p>
        <div className="mt-2 divide-y">
          <ConsentToggle id="c-auto" label="Automatic trip detection" description="Suggest trips for you to confirm." checked={s.consent.autoDetect} onChange={(v) => s.setConsent({ autoDetect: v })} />
          <ConsentToggle id="c-lb" label="Show my name on the leaderboard" description="Otherwise you appear anonymously." checked={s.consent.leaderboard} onChange={(v) => s.setConsent({ leaderboard: v })} />
          <ConsentToggle id="c-team" label="Include me in team totals" description="Adds your footprint to anonymous team and company figures." checked={s.consent.teamAggregates} onChange={(v) => s.setConsent({ teamAggregates: v })} />
        </div>
      </Card>

      <Card className="space-y-2">
        <h2 className="font-bold">Your data</h2>
        <Button variant="outline" className="w-full justify-start" onClick={download}><Download className="size-4" /> Download my data</Button>
        <AlertDialog>
          <AlertDialogTrigger asChild><Button variant="outline" className="w-full justify-start text-destructive"><Trash2 className="size-4" /> Delete my data</Button></AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete all your EcoTrack data?</AlertDialogTitle>
              <AlertDialogDescription>This permanently removes your trips, habits and settings. Team totals will be recalculated without you. This can't be undone.</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Keep my data</AlertDialogCancel>
              <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => { s.deleteMyData(); toast.success("Your data was deleted"); nav({ to: "/" }); }}>Delete everything</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </Card>

      <Button variant="ghost" className="w-full" onClick={() => { s.signOut(); nav({ to: "/" }); }}><LogOut className="size-4" /> Sign out</Button>
    </div>
  );
}
