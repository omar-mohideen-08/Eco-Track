import { createFileRoute } from "@tanstack/react-router";
import { CalendarHeart, Gift, TreePine } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Card, celebrate, CountUp, PageTitle } from "@/components/eco/primitives";
import { REWARDS } from "@/data/seed";
import { useApp } from "@/store/app-store";
import { totalPoints } from "@/utils/stats";
import { DAILY_POINTS_CAP } from "@/utils/emissions";

export const Route = createFileRoute("/app/rewards")({
  head: () => ({ meta: [{ title: "Rewards — EcoTrack" }, { name: "description", content: "Redeem green points for vouchers, leave and trees." }, { property: "og:title", content: "Rewards — EcoTrack" }, { property: "og:description", content: "Green points rewards." }] }),
  component: Rewards,
});

const ICON = { voucher: Gift, leave: CalendarHeart, tree: TreePine };

function Rewards() {
  const logs = useApp((s) => s.logs);
  const claimed = useApp((s) => s.claimedRewards);
  const claim = useApp((s) => s.claimReward);
  const points = totalPoints(logs);
  return (
    <div className="space-y-3">
      <PageTitle title="Rewards" />
      <Card className="bg-hero text-primary-foreground">
        <p className="text-sm opacity-85">Your green points</p>
        <p className="font-display text-4xl font-extrabold"><CountUp value={points} /></p>
        <p className="mt-1 text-xs opacity-80">Earned for low-carbon trips · max {DAILY_POINTS_CAP} points per day</p>
      </Card>
      {REWARDS.map((r) => {
        const Icon = ICON[r.kind];
        const pct = Math.min(100, Math.round((points / r.points) * 100));
        const done = claimed.includes(r.id);
        return (
          <Card key={r.id} className="p-4">
            <div className="flex items-center gap-3">
              <span className="grid size-11 place-items-center rounded-xl bg-secondary"><Icon className="size-5" aria-hidden /></span>
              <div className="flex-1">
                <p className="font-semibold">{r.title}</p>
                <p className="text-xs text-muted-foreground">{r.points.toLocaleString("en-IN")} points</p>
              </div>
              <Button size="sm" disabled={pct < 100 || done} onClick={() => { claim(r.id); celebrate(); toast.success("Reward claimed! HR will be in touch."); }}>
                {done ? "Claimed" : pct < 100 ? `${pct}%` : "Redeem"}
              </Button>
            </div>
            <Progress value={pct} className="mt-3 h-2" aria-label={`${pct}% towards ${r.title}`} />
          </Card>
        );
      })}
    </div>
  );
}
