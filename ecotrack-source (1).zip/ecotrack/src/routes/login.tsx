import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Lock, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Logo } from "@/components/eco/primitives";
import { COMPANY } from "@/data/seed";
import { useApp } from "@/store/app-store";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Sign in — EcoTrack" }, { name: "description", content: "Sign in to EcoTrack with your work email." }, { property: "og:title", content: "Sign in — EcoTrack" }, { property: "og:description", content: "Sign in with your company email." }] }),
  component: Login,
});

/** Mock auth: only the company's work-email domain is accepted. */
function Login() {
  const [email, setEmail] = useState(`priya.raman@${COMPANY.domain}`);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const signIn = useApp((s) => s.signIn);
  const onboarded = useApp((s) => s.onboarded);
  const nav = useNavigate();

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const ok = /^[^\s@]+@([^\s@]+)$/.exec(email.trim());
    if (!ok) return setError("Please enter a valid email address.");
    if ((ok[1] ?? "").toLowerCase() !== COMPANY.domain) return setError(`Please use your work email ending in @${COMPANY.domain}.`);
    setError("");
    setLoading(true);
    setTimeout(() => { signIn(email.trim()); nav({ to: onboarded ? "/app" : "/onboarding" }); }, 500);
  };

  return (
    <main className="grid min-h-screen place-items-center px-5">
      <form onSubmit={submit} className="w-full max-w-sm animate-rise rounded-3xl border bg-card p-7 shadow-card" noValidate>
        <Logo />
        <h1 className="mt-6 text-2xl font-bold">Welcome back</h1>
        <p className="mt-1 text-sm text-muted-foreground">Sign in with your {COMPANY.name} work email.</p>
        <label htmlFor="email" className="mt-6 block text-sm font-semibold">Work email</label>
        <div className="relative mt-1.5">
          <Mail className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <Input id="email" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className="h-11 pl-9" aria-invalid={!!error} aria-describedby={error ? "email-err" : undefined} />
        </div>
        {error && <p id="email-err" role="alert" className="mt-2 text-sm font-medium text-destructive">{error}</p>}
        <Button type="submit" className="mt-5 h-11 w-full" disabled={loading}>{loading ? "Sending magic link…" : "Continue"}</Button>
        <p className="mt-4 flex items-center gap-1.5 text-xs text-muted-foreground"><Lock className="size-3" aria-hidden /> Demo sign-in — no password needed.</p>
      </form>
    </main>
  );
}
