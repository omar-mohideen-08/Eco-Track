/**
 * Global app state (Zustand, in-memory only — nothing is persisted).
 * Holds the signed-in user, their logs, consent settings and shared demo data.
 */
import { create } from "zustand";
import { SEED_CHALLENGES, SEED_DETECTED, seedUserLogs, OFFICES, type Challenge, type DetectedTrip, type Office, type TripLog } from "@/data/seed";
import { baselineMonthly, calculateEmissions, habitEmissions, type HabitCheckIn, type Mode } from "@/utils/emissions";

export interface Baseline { distanceKm: number; mode: Mode; vehicle: string; daysPerWeek: number }
export interface Consent { autoDetect: boolean; leaderboard: boolean; teamAggregates: boolean }
export interface HabitLog extends HabitCheckIn { id: string; date: string; kg: number }
export interface Invite { email: string; status: "sent" | "joined" }

interface State {
  user: { name: string; email: string; team: string } | null;
  onboarded: boolean;
  baseline: Baseline;
  consent: Consent;
  logs: TripLog[];
  habits: HabitLog[];
  detected: DetectedTrip[];
  acceptedTips: string[];
  claimedRewards: string[];
  challenges: Challenge[];
  offices: Office[];
  invites: Invite[];
  theme: "light" | "dark";
  dashboardWeeks: 4 | 8;
  signIn: (email: string) => void;
  signOut: () => void;
  completeOnboarding: (b: Baseline, autoDetect: boolean) => void;
  addLog: (mode: Mode, km: number, source?: "manual" | "auto") => void;
  addHabit: (h: HabitCheckIn) => void;
  resolveDetected: (id: string, action: "confirm" | "dismiss", edit?: { mode: Mode; km: number }) => void;
  setConsent: (c: Partial<Consent>) => void;
  acceptTip: (id: string) => void;
  claimReward: (id: string) => void;
  addChallenge: (c: Omit<Challenge, "id" | "status" | "participants" | "progress">) => void;
  addOffice: (name: string, city: string) => void;
  removeOffice: (id: string) => void;
  invite: (emails: string[]) => void;
  deleteMyData: () => void;
  toggleTheme: () => void;
  setDashboardWeeks: (w: 4 | 8) => void;
}

const today = () => new Date().toISOString().slice(0, 10);
const uid = () => Math.random().toString(36).slice(2, 9);

export const DEFAULT_BASELINE: Baseline = { distanceKm: 14, mode: "car", vehicle: "Petrol hatchback", daysPerWeek: 4 };

export const useApp = create<State>((set) => ({
  user: null,
  onboarded: false,
  baseline: DEFAULT_BASELINE,
  consent: { autoDetect: true, leaderboard: true, teamAggregates: true },
  logs: seedUserLogs(),
  habits: [],
  detected: SEED_DETECTED,
  acceptedTips: [],
  claimedRewards: [],
  challenges: SEED_CHALLENGES,
  offices: OFFICES,
  invites: [
    { email: "rahul.sharma@acmetech.in", status: "joined" },
    { email: "new.joinee@acmetech.in", status: "sent" },
  ],
  theme: "light",
  dashboardWeeks: 8,

  signIn: (email) => {
    const local = (email.split("@")[0] ?? "").split(/[._]/).map((p) => (p[0]?.toUpperCase() ?? "") + p.slice(1));
    set({ user: { name: local.join(" ") || "Priya Raman", email, team: "Engineering" } });
  },
  signOut: () => set({ user: null }),
  completeOnboarding: (baseline, autoDetect) =>
    set((s) => ({ baseline, onboarded: true, consent: { ...s.consent, autoDetect } })),
  addLog: (mode, km, source = "manual") =>
    set((s) => ({ logs: [...s.logs, { id: uid(), date: today(), mode, km, kg: calculateEmissions(mode, km), source }] })),
  addHabit: (h) => set((s) => ({ habits: [...s.habits, { ...h, id: uid(), date: today(), kg: habitEmissions(h) }] })),
  resolveDetected: (id, action, edit) =>
    set((s) => {
      const trip = s.detected.find((d) => d.id === id);
      const detected = s.detected.filter((d) => d.id !== id);
      if (!trip || action === "dismiss") return { detected };
      const mode = edit?.mode ?? trip.mode;
      const km = edit?.km ?? trip.km;
      return { detected, logs: [...s.logs, { id: uid(), date: today(), mode, km, kg: calculateEmissions(mode, km), source: "auto" }] };
    }),
  setConsent: (c) => set((s) => ({ consent: { ...s.consent, ...c } })),
  acceptTip: (id) => set((s) => ({ acceptedTips: [...new Set([...s.acceptedTips, id])] })),
  claimReward: (id) => set((s) => ({ claimedRewards: [...s.claimedRewards, id] })),
  addChallenge: (c) =>
    set((s) => ({ challenges: [{ ...c, id: uid(), status: "active", participants: 0, progress: 0 }, ...s.challenges] })),
  addOffice: (name, city) => set((s) => ({ offices: [...s.offices, { id: uid(), name, city }] })),
  removeOffice: (id) => set((s) => ({ offices: s.offices.filter((o) => o.id !== id) })),
  invite: (emails) => set((s) => ({ invites: [...emails.map((email) => ({ email, status: "sent" as const })), ...s.invites] })),
  deleteMyData: () => set({ logs: [], habits: [], detected: [], acceptedTips: [], claimedRewards: [], user: null, onboarded: false }),
  toggleTheme: () => set((s) => ({ theme: s.theme === "light" ? "dark" : "light" })),
  setDashboardWeeks: (dashboardWeeks) => set({ dashboardWeeks }),
}));

/** Monthly baseline in kg for the current user. */
export const selectBaselineMonthly = (s: State) => baselineMonthly(s.baseline.mode, s.baseline.distanceKm, s.baseline.daysPerWeek);
